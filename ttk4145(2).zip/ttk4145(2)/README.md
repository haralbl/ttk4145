# ttk4145
Heisprosjekt i Go

STAY AWAY, BITCHES!!!
