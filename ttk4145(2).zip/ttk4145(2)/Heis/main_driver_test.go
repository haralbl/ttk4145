package main

import(
	"./driver"
	"fmt"
)

func main() {
	fmt.Printf("I'm running main\n")
	driver.Test()
}
